int desapilar_asignacion(PilaDeshacer *p, Asignacion *asignacion) {
    if (pila_vacia(p)) {
        puts("ERROR. La pila esta vacia, no hay asignacion para deshacer");
        return 0;
    }

    NodoPila *temp = p->tope;
    *asignacion = temp->asignacion;
    p->tope = temp->siguiente;
    free(temp);
    p->total--;
    return 1;
}
