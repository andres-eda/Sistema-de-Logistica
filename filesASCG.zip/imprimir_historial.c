void imprimir_historial(Historial *h) {
    if (historial_vacio(h)) {
        puts("El historial de entregas esta vacio");
        return;
    }

    puts("\n========== HISTORIAL DE ENTREGAS ==========");
    printf("Total de entregas: %d\n\n", h->total_entregas);

    NodoHistorial *actual = h->cabeza;
    int numero = 1;
    while (actual != NULL) {
        printf("[Entrega #%d]\n", numero);
        printf("  ID Paquete: %d\n", actual->entrega.paquete.id);
        printf("  Destino: %s\n", actual->entrega.paquete.destino);
        printf("  Peso: %.2f kg\n", actual->entrega.paquete.peso_kg);
        printf("  Camion ID: %d\n", actual->entrega.id_camion);
        printf("\n");

        actual = actual->siguiente;
        numero++;
    }
    puts("=========================================\n");
}
