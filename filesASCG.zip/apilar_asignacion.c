int apilar_asignacion(PilaDeshacer *p, Asignacion asignacion) {
    NodoPila *nuevo = (NodoPila *)malloc(sizeof(NodoPila));
    if (nuevo == NULL) {
        puts("ERROR 1. Error en memoria dinamica");
        return 0;
    }

    nuevo->asignacion = asignacion;
    nuevo->siguiente = p->tope;
    p->tope = nuevo;
    p->total++;
    return 1;
}
